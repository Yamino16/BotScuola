import os
import time
import requests
from datetime import datetime
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

from bs4 import BeautifulSoup

# =========================
# CONFIGURAZIONE GENERALE
# =========================
TELEGRAM_TOKEN = "HIDDEN_FOR_SECURITY"
URL_SITO_ORARIO = "HIDDEN_FOR_SECURITY"
NOME_FILE_IMMAGINE = "orario_temporaneo.png"

# =========================
# CONFIGURAZIONE DISCORD
# =========================
DISCORD_TOKEN = "HIDDEN_FOR_SECURITY"
DISCORD_CHANNEL_ID = "HIDDEN_FOR_SECURITY"

def crea_driver():
    options = webdriver.ChromeOptions()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")
    
    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options
    )
    return driver

# =========================
# LOGICA DI SCREENSHOT ORARIO
# =========================
def cattura_orario_sito(ricerca_utente):
    driver = crea_driver()
    driver.get(URL_SITO_ORARIO)
    
    try:
        wait = WebDriverWait(driver, 15)
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
        
        soup = BeautifulSoup(driver.page_source, "html.parser")
        script_da_eseguire = None
        nome_effettivo = ""
        tipo_ricerca = ""
        
        for link in soup.find_all("a", onclick=True):
            onclick_str = link["onclick"]
            if "OrarioClasse" in onclick_str:
                testo_classe = link.get_text(strip=True).upper()
                if ricerca_utente == testo_classe or ricerca_utente in testo_classe:
                    script_da_eseguire = onclick_str
                    nome_effettivo = link.get_text(strip=True)
                    tipo_ricerca = "CLASSE"
                    break
        
        if not script_da_eseguire:
            for link in soup.find_all("a", onclick=True):
                onclick_str = link["onclick"]
                if "OrarioDocente" in onclick_str:
                    testo_docente = link.get_text(strip=True).upper()
                    if ricerca_utente in testo_docente:
                        script_da_eseguire = onclick_str
                        nome_effettivo = link.get_text(strip=True)
                        tipo_ricerca = "DOCENTE"
                        break
                        
        if not script_da_eseguire:
            return None, f"❌ Impossibile trovare '{ricerca_utente}' tra le classi o i docenti."
            
        driver.execute_script(script_da_eseguire)
        time.sleep(4)
        
        try:
            tabella_elemento = driver.find_element(By.ID, "Tclassi2018")
        except:
            try:
                tabella_elemento = driver.find_element(By.ID, "Torario")
            except:
                tabella_elemento = driver.find_element(By.TAG_NAME, "table")
        
        if os.path.exists(NOME_FILE_IMMAGINE):
            try: os.remove(NOME_FILE_IMMAGINE)
            except: pass
            
        tabella_elemento.screenshot(NOME_FILE_IMMAGINE)
        didascalia = f"📅 *ORARIO SCOLASTICO - {tipo_ricerca}: {nome_effettivo}*"
        return NOME_FILE_IMMAGINE, didascalia

    except Exception as e:
        return None, f"❌ Errore nel recupero dell'orario: {str(e)}"
    finally:
        driver.quit()

# =========================
# LOGICA SOSTITUZIONI DA DISCORD (CRONOLOGIA)
# =========================
def leggi_sostituzioni_da_discord(classe_filtro=None):
    url = f"https://discord.com/api/v9/channels/{DISCORD_CHANNEL_ID}/messages?limit=50"
    
    headers = {
        "Authorization": DISCORD_TOKEN,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Content-Type": "application/json"
    }
    
    try:
        risposta = requests.get(url, headers=headers)
        
        if risposta.status_code != 200:
            print(f"\n[DEBUG DISCORD] Errore di connessione! Stato HTTP: {risposta.status_code}")
            if risposta.status_code == 401:
                return "❌ Errore Discord (401): Il token inserito è scaduto. Rigeneralo dal browser."
            return f"❌ Errore di connessione a Discord (Codice {risposta.status_code})."
            
        messaggi = risposta.json()
        if not messaggi:
            return "⚠️ Il canale Discord delle sostituzioni è vuoto."
            
        # CASO 1: Nessun filtro inserito (es. /sostituzioni) -> Mostra gli ultimi 8 avvisi generali della scuola
        if not classe_filtro:
            testo_completo = "🔄 *ULTIMI AVVISI SOSTITUZIONI DA DISCORD*\n\n"
            contatore = 0
            
            for msg in messaggi:
                contenuto_msg = msg.get("content", "").strip()
                if contenuto_msg and contatore < 8:
                    testo_completo += f"📋 {contenuto_msg}\n"
                    testo_completo += "‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\n"
                    contatore += 1
            return testo_completo

        # CASO 2: Filtro per classe inserito (es. /sostituzioni 2BG) -> Cerca in tutta la cronologia recente
        classe_filtro = classe_filtro.upper()
        sostituzioni_trovate = []
        
        for msg in messaggi:
            contenuto_msg = msg.get("content", "").strip()
            if not contenuto_msg:
                continue
                
            # Rende il controllo flessibile eliminando i trattini (es. 4A-EA2 diventa 4AEA2)
            contenuto_pulito = contenuto_msg.upper().replace("-", "")
            classe_cercata_pulita = classe_filtro.replace("-", "")
            
            if classe_cercata_pulita in contenuto_pulito:
                sostituzioni_trovate.append(f"🔹 {contenuto_msg}")

        if sostituzioni_trovate:
            sostituzioni_trovate.reverse()  # Mette le sostituzioni in ordine cronologico corretto
            risultato = f"🔍 *TUTTE LE SOSTITUZIONI TROVATE PER LA CLASSE {classe_filtro}*\n_(Oggi e Domani se presenti)_\n\n"
            risultato += "\n\n--------------------------\n\n".join(sostituzioni_trovate)
            return risultato
        else:
            return f"🔍 *SOSTITUZIONI CLASSE {classe_filtro}*\n\n✅ Ottimo! Non è stata trovata nessuna sostituzione per la tua classe tra gli ultimi avvisi pubblicati."

    except Exception as e:
        return f"❌ Errore critico durante la lettura da Discord: {str(e)}"

# =========================
# COMANDI BOT TELEGRAM
# =========================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    testo = (
        "📚 *BOT ORARIO & SOSTITUZIONI ITI MEDI by Yamino*\n\n"
        "Comandi disponibili:\n\n"
        "📸 *Orario Scolastico:*\n"
        "`/orario nomeclasse` - Vedi screenshot orario classe\n\n"
        "📝 *Sostituzioni (da Discord):*\n"
        "`/sostituzioni nomeclasse` - Oggi e Domani (se disponibili)\n"
    )
    await update.message.reply_text(testo, parse_mode="Markdown")

async def orario(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) == 0:
        await update.message.reply_text("⚠️ Specifica cosa cercare! Esempio: `/orario 4HI`", parse_mode="Markdown")
        return

    ricerca = " ".join(context.args).upper()
    messaggio_attesa = await update.message.reply_text(f"📸 Ricerca per *{ricerca}* in corso...", parse_mode="Markdown")

    percorso_immagine, risultato_o_errore = cattura_orario_sito(ricerca)
    
    if percorso_immagine and os.path.exists(percorso_immagine):
        try:
            await messaggio_attesa.delete()
            with open(percorso_immagine, "rb") as foto:
                await update.message.reply_photo(
                    photo=foto, caption=risultato_o_errore, parse_mode="Markdown",
                    read_timeout=60, write_timeout=60
                )
        except Exception as e:
            await update.message.reply_text(f"❌ Errore nell'invio a Telegram: {str(e)}")
        finally:
            if os.path.exists(percorso_immagine): os.remove(percorso_immagine)
    else:
        await messaggio_attesa.edit_text(risultato_o_errore, parse_mode="Markdown")

async def sostituzioni(update: Update, context: ContextTypes.DEFAULT_TYPE):
    classe_richiesta = context.args[0] if len(context.args) > 0 else None
    
    if classe_richiesta:
        testo_attesa = f"🔍 Ricerca di tutte le sostituzioni recenti per la classe *{classe_richiesta.upper()}*..."
    else:
        testo_attesa = "🔍 Estrazione degli ultimi avvisi dal canale Discord..."
        
    messaggio_attesa = await update.message.reply_text(testo_attesa, parse_mode="Markdown")

    risultato_testo = leggi_sostituzioni_da_discord(classe_richiesta)
    
    await messaggio_attesa.edit_text(risultato_testo, parse_mode="Markdown")

# =========================
# AVVIO APPLICAZIONE
# =========================
if __name__ == "__main__":
    print("🤖 Bot Orario & Sostituzioni Discord Online!")
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).read_timeout(60).write_timeout(60).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("orario", orario))
    app.add_handler(CommandHandler("sostituzioni", sostituzioni))
    
    app.run_polling()